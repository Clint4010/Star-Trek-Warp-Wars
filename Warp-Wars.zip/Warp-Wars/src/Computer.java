public class Computer {

    static int score;

}
