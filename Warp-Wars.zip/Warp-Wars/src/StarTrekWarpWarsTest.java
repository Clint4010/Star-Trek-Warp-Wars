public class StarTrekWarpWarsTest {


    public static void main(String[] args) throws Exception {


        StarTrekWarpWars starTrek = new StarTrekWarpWars();

    }
}
